

#ifndef CAR_BLACKBOX_DEF_H
#define	CAR_BLACKBOX_DEF_H


void display_dashboard(unsigned char event[],unsigned char speed);
void log_event(unsigned char event[],unsigned char speed);
void clear_screen();
unsigned char login(unsigned char key,unsigned char reset_flag);
unsigned char menu_screen (unsigned char key,unsigned char reset_flag);
unsigned char press_type(unsigned char key);
unsigned char viewlog_screen(unsigned char reset_flag);
unsigned char clear_log(unsigned char reset_flag);
unsigned char set_time_screen(unsigned char reset_flag);
unsigned char reset_password(unsigned char key,unsigned char reset_flag);
unsigned char download_screen(unsigned char reset_flag);

#endif	/* CAR_BLACKBOX_DEF_H */

