// definition of car black box
#include "main.h"

unsigned char clock_reg[3];
char time[7];  // "HHMMSS"
char log[11];// "HHMMSSEVSP"
char log_pos,log_no;
unsigned char sec;
unsigned char return_time;
unsigned char *menu []= { "View log","Clear log","Download log","Set time","Reset password"};
unsigned char menu_pos,clear_flag=1;

static void get_time()
{
    clock_reg[0] = read_ds1307(HOUR_ADDR); // HH -> BCD 
    clock_reg[1] = read_ds1307(MIN_ADDR); // MM -> BCD 
    clock_reg[2] = read_ds1307(SEC_ADDR); // SS -> BCD 
    /* To store the time in HH:MM:SS format */
   
    // HH -> 
    time[0] = ((clock_reg[0] >> 4) & 0x03) + '0';
    time[1] = (clock_reg[0] & 0x0F) + '0';
    
    // MM 
    time[2] = ((clock_reg[1] >> 4) & 0x07) + '0';
    time[3] = (clock_reg[1] & 0x0F) + '0';
    // SS
    time[4] = ((clock_reg[2] >> 4) & 0x07) + '0';
    time[5] = (clock_reg[2] & 0x0F) + '0';
    time[6] = '\0';
}

//display time

void display_time()
{
    get_time();
    //HH:MM:SS
    clcd_putch( time[0] , LINE2(2));
    clcd_putch( time[1] , LINE2(3));
    clcd_putch( ':' , LINE2(4));
    clcd_putch( time[2] , LINE2(5));
    clcd_putch( time[3] , LINE2(6));
    clcd_putch( ':' , LINE2(7));
    clcd_putch( time[4] , LINE2(8));
    clcd_putch( time[5] , LINE2(9));
}

//display dashboard

void display_dashboard(unsigned char event[],unsigned char speed)
{
    clcd_print("TIME     E  SP" , LINE1(2));
    //display time
    
    //display event
    clcd_print(event , LINE2(11));
    //display speed
    clcd_putch(speed / 10 + '0' , LINE2(14));
    clcd_putch(speed % 10 + '0' , LINE2(15));
    //display time
    display_time(); 
}

void store_event()
{
    char addr;
    if(log_pos==10)
        log_pos=0;
    addr = 0x05 + log_pos * 10;
    ext_eeprom_24C02_str_write(addr,log);
    log_pos++;
    if(log_no<10)
        log_no++;
}

void log_event(unsigned char event[],unsigned char speed)
{
   get_time();
   strncpy(log , time , 6);
   strncpy(&log[6] , event , 2);
   
   log[8]=speed / 10 + '0';
   log[9]=speed % 10 + '0';
   log[10]='\0'; 
   store_event();
   clear_flag=1;
}

unsigned char login(unsigned char key,unsigned char reset_flag)
{
    static char user_password[4];
    static char i;
    static char attempt_left;
    if(reset_flag == RESET_PASSWORD)
    {
        i=0;
        attempt_left = 3;
        user_password[0] = '\0';
        user_password[1] = '\0';
        user_password[2] = '\0';
        user_password[3] = '\0';
        key = ALL_RELEASED;
        return_time = 5;       
    }
    if (return_time == 0)
    {
        //change dashboard screen
        return RETURN_BACK;
    }
    //sw4 = 1 . sw5 = 0
    if(key == SW4 && i<4)
        {
            clcd_putch('*' , LINE2(4+i));
            user_password[i] = '1';
            i++;
            return_time = 5;
        }
    else if(key == SW5 && i<4)
    {
        clcd_putch('*' , LINE2(4+i));
        user_password[i] = '0';
        i++;
        return_time = 5;
    }
    if(i == 4)
    {
        char s_password[4];
        for(int j = 0;j < 4; j++)
        {
            //read saved password to s_password byte by byte
            s_password[j] = ext_eeprom_24C02_read(j);
        }
        //compare saved password and user password
        if (strncmp(s_password,user_password, 4 )== 0)
        {
            clear_screen();
            clcd_write(DISP_ON_AND_CURSOR_OFF, INST_MODE);
            __delay_us(500);
            clcd_print("login success" , LINE1(1));
            __delay_ms(3000);
            //change to menu screen
            return LOGIN_SUCCESS;
        }
        else
        {
            attempt_left--;
            if(attempt_left == 0)
            {
                //display the blocked screen
                clear_screen();
                clcd_write(DISP_ON_AND_CURSOR_OFF, INST_MODE);
                __delay_us(500);
                clcd_print("You are blocked" , LINE1(0));
                clcd_print("wait for" , LINE2(0));
                //wait for 60 sec
                sec = 60; 
                //until second 0
                while(sec)
                {
                    clcd_putch(sec / 10 + '0',LINE2(9));  
                    clcd_putch(sec % 10 + '0',LINE2(10));
                }
                clcd_print("sec" , LINE2(13));
                attempt_left = 3;
                
            }
            else
            {
                clear_screen();
                clcd_write(DISP_ON_AND_CURSOR_OFF, INST_MODE);
                __delay_us(500);
                clcd_print("Wrong password" , LINE1(0));
                clcd_print("attempts left" , LINE2(2));
                clcd_putch(attempt_left + '0',LINE2(0));
                __delay_ms(2500);                
            }
            clear_screen();
            clcd_print("ENTER PASSWORD",LINE1(1));
            clcd_write(LINE2(4), INST_MODE);
            clcd_write(DISP_ON_AND_CURSOR_ON, INST_MODE);
            __delay_us(500);
            i=0;
            return_time = 5;
        }
    }
    
}

void clear_screen()
{
    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
        __delay_us(500);
}

unsigned char menu_screen (unsigned char key,unsigned char reset_flag)
{
    if (reset_flag == RESET_MENU)
    {
        menu_pos = 0;
        return_time = 7;
    }
    if (return_time == 0)
    {
        //change dashboard screen
        clear_screen();
        return RETURN_BACK;
    }
    if (key == SHORTPRESS_SW4 && menu_pos >0)
    {
        //decrement menu
        return_time = 7;
        clear_screen();
        menu_pos--;
    }
    if (key == SHORTPRESS_SW5 && menu_pos <4)
    {
        //increment menu
        return_time = 7;
        clear_screen();
        menu_pos++;
    }
    if (menu_pos == 4)
    {
        clcd_putch('*',LINE2(0));
        clcd_print(menu[menu_pos-1], LINE1(1));
        clcd_print(menu[menu_pos] , LINE2(1)); 
    }
    else
    {
        clcd_putch('*',LINE1(0));
        clcd_print(menu[menu_pos], LINE1(1));
        clcd_print(menu[menu_pos+1] , LINE2(1));
    }
    return menu_pos;
    
}


unsigned char press_type(unsigned char key)
{
    static unsigned char last_key = ALL_RELEASED;
    static unsigned long int press_delay = 0;
    static enum { IDLE, PRESSED } state = IDLE;

    switch (state)
    {
        case IDLE:
            if (key == SW4 || key == SW5)
            {
                last_key = key;
                press_delay = 1;
                state = PRESSED;
            }
            break;

        case PRESSED:
            if (key == last_key)
            {
                press_delay++;

                if (press_delay > 15)
                {
                    // Long press detected
                    unsigned char longpress = (last_key == SW4) ? LONGPRESS_SW4 : LONGPRESS_SW5;
                    state = IDLE;  // Reset state after returning event
                    return longpress;
                }
            }
            else if (key == ALL_RELEASED)
            {
                // Short press detected
                unsigned char shortpress = (last_key == SW4) ? SHORTPRESS_SW4 : SHORTPRESS_SW5;
                state = IDLE;
                return shortpress;
            }
            break;
    }

    return ALL_RELEASED;
}
unsigned char viewlog_screen(unsigned char reset_flag)
{
    static char pos = 0;
    static unsigned char view_key = ALL_RELEASED,prev_key = ALL_RELEASED;
    static unsigned long int view_pressdelay = 0;
    char addr;
    if (reset_flag == RESET_MENU)
    {
        view_pressdelay =  0;
        pos =0;
    }
    // Read current key press level
    view_key = read_digital_keypad(LEVEL);
    // Detect long press inside the same block
    if (view_key == SW4 || view_key == SW5)
    {
        if(view_key==SW4)
            prev_key=SW4;
        else
            prev_key=SW5;
        view_pressdelay++;
        if (view_pressdelay > 20 && view_key == SW4)
        {
            view_pressdelay = 0; 
            return GOTO_DASHBOARD;  

        }
        else if (view_pressdelay > 20 && view_key == SW5)
        {  
            view_pressdelay = 0; 
            return GOTO_MAINMENU;
        }

    }
    else if (view_pressdelay>0&&view_pressdelay < 20 && prev_key == SW4)
    {
        view_pressdelay = 0; 
        if(pos<log_no-1)
            pos++; 
    }
    else if (view_pressdelay>0&&view_pressdelay < 20 && prev_key == SW5)
    {
        view_pressdelay = 0; 
        if(pos>0)
            pos--; 
    }
    else
        view_pressdelay = 0;    

    if ( clear_flag == 1  )
    {
        if(pos>log_no)
            addr = 0x05 + ((pos-1) * 10);
        else
            addr = 0x05 + (pos * 10);

        for (char i = 0; i < 10; i++)
            log[i] = ext_eeprom_24C02_read(addr + i);
        log[10] = '\0';

        clcd_print("# TIME     E  SP", LINE1(0));
        clcd_putch(pos + '0', LINE2(0));

        clcd_putch(log[0], LINE2(2));
        clcd_putch(log[1], LINE2(3));
        clcd_putch(':', LINE2(4));
        clcd_putch(log[2], LINE2(5));
        clcd_putch(log[3], LINE2(6));
        clcd_putch(':', LINE2(7));
        clcd_putch(log[4], LINE2(8));
        clcd_putch(log[5], LINE2(9));
        
        clcd_putch(log[6], LINE2(11));
        clcd_putch(log[7], LINE2(12));
        clcd_putch(log[8], LINE2(14));
        clcd_putch(log[9], LINE2(15));

    }
    else if (clear_flag == 0)
    {
        clcd_print("No logs found", LINE1(1));
    }

    return 0;
}


unsigned char clear_log(unsigned char reset_flag)
{
    static unsigned char view_key = ALL_RELEASED,prev_key = ALL_RELEASED;
    static unsigned long int view_pressdelay = 0;
    if (reset_flag == RESET_MENU)
    {
        view_pressdelay =  0;
    }
    // Read current key press level
    view_key = read_digital_keypad(LEVEL);
    // Detect long press inside the same block
    if (view_key == SW4 || view_key == SW5)
    {
        if(view_key==SW4)
            prev_key=SW4;
        else
            prev_key=SW5;
        view_pressdelay++;
        if (view_pressdelay > 20 && view_key == SW4)
        {
            view_pressdelay = 0; 
            return GOTO_DASHBOARD;  

        }
        else if (view_pressdelay > 20 && view_key == SW5)
        {  
            view_pressdelay = 0; 
            return GOTO_MAINMENU;
        }

    }
    else
        view_pressdelay = 0; 
    clear_flag=0;
    log_pos=0;
    log_no=0;
    clcd_print("Logs  cleared", LINE1(2));
    clcd_print("successfully", LINE2(2));    
}

unsigned char set_time_screen(unsigned char reset_flag)
{
    static unsigned char set_field = 2; // Start with SS (0 = HH, 1 = MM, 2 = SS)
    static unsigned char time_buf[3];   // [HH, MM, SS] in BCD
    static unsigned char prev_key = ALL_RELEASED;
    static unsigned long press_delay = 0;
    unsigned char key = read_digital_keypad(LEVEL);
    static unsigned int blink_counter = 0;
    static unsigned char blink_flag = 1;

    blink_counter++;
    if (blink_counter >= 5)  // adjust blink speed (5 x 50ms = 250ms)
    {
        blink_counter = 0;
        blink_flag = !blink_flag;  // toggle visibility
    }

    if (reset_flag == RESET_MENU)
    {
        set_field = 2;         // Start with SS
        press_delay = 0;
        // Load current time from RTC into buffer
        time_buf[0] = read_ds1307(HOUR_ADDR); // HH
        time_buf[1] = read_ds1307(MIN_ADDR);  // MM
        time_buf[2] = read_ds1307(SEC_ADDR);  // SS
    }

    // Detect press behavior
    if (key == SW4 || key == SW5)
    {
        prev_key = key;
        press_delay++;
        if (press_delay > 20)
        {
            // Long Press
            if (key == SW4)
            {
                // Save time to RTC
                write_ds1307(HOUR_ADDR, time_buf[0]);
                write_ds1307(MIN_ADDR, time_buf[1]);
                write_ds1307(SEC_ADDR, time_buf[2]);
                clear_screen();
                clcd_print("Time changed" , LINE1(1));
                clcd_print("Successfully" , LINE2(1));
                __delay_ms(3000);
                return_time=7;
                return GOTO_MAINMENU;
            }
            else if (key == SW5)
            {
                return GOTO_DASHBOARD;
            }
        }
    }
    else if (press_delay > 0 && press_delay < 20)
    {
        // Short Press
        if (prev_key == SW4)
        {
            // Increment selected field
            unsigned char high = (time_buf[set_field] >> 4) & 0x0F;
            unsigned char low  = time_buf[set_field] & 0x0F;

            if (set_field == 0) // HH
            {
                low++;
                if ((high * 10 + low) >= 24)
                {
                    high = 0;
                    low = 0;
                }
            }
            else if (set_field == 1 || set_field == 2) // MM or SS
            {
                low++;
                if ((high * 10 + low) >= 60)
                {
                    high = 0;
                    low = 0;
                }
            }

            if (low > 9)
            {
                low = 0;
                high++;
            }

            time_buf[set_field] = (high << 4) | (low & 0x0F);
        }
        else if (prev_key == SW5)
        {
            // Move to next field in order: SS -> MM -> HH -> SS ...
            if (set_field == 2)
                set_field = 1; // SS -> MM
            else if (set_field == 1)
                set_field = 0; // MM -> HH
            else
                set_field = 2; // HH -> SS
        }

        press_delay = 0;
    }
    else
    {
        press_delay = 0;
    }

    // Display time and highlight current field
    clcd_print(" SET TIME MODE ", LINE1(0));
    
    // Extract BCD to ASCII
    unsigned char hh = time_buf[0];
    unsigned char mm = time_buf[1];
    unsigned char ss = time_buf[2];

    // Hours
    if (set_field == 0 && blink_flag == 0)
    {
        clcd_putch(' ', LINE2(2));
        clcd_putch(' ', LINE2(3));
    }
    else
    {
        clcd_putch(((hh >> 4) & 0x0F) + '0', LINE2(2));
        clcd_putch((hh & 0x0F) + '0', LINE2(3));
    }

    clcd_putch(':', LINE2(4));

    // Minutes
    if (set_field == 1 && blink_flag == 0)
    {
        clcd_putch(' ', LINE2(5));
        clcd_putch(' ', LINE2(6));
    }
    else
    {
        clcd_putch(((mm >> 4) & 0x0F) + '0', LINE2(5));
        clcd_putch((mm & 0x0F) + '0', LINE2(6));
    }

    clcd_putch(':', LINE2(7));

    // Seconds
    if (set_field == 2 && blink_flag == 0)
    {
        clcd_putch(' ', LINE2(8));
        clcd_putch(' ', LINE2(9));
    }
    else
    {
        clcd_putch(((ss >> 4) & 0x0F) + '0', LINE2(8));
        clcd_putch((ss & 0x0F) + '0', LINE2(9));
    }

    return 0;
}
unsigned char reset_password(unsigned char key,unsigned char reset_flag)
{
    static char new_password[5];
    static char confirm_password[5];
    static unsigned char i = 0;
    static unsigned char stage = 0; // 0 = new password, 1 = confirm password
    static unsigned char result_delay = 0;
    if(reset_flag==RESET_MENU)
    {
        key=ALL_RELEASED;
        return_time=7;
        stage=0;
    }
    if (return_time == 0)
    {
        //change dashboard screen
        clear_screen();
        stage=0;
        return GOTO_MAINMENU;
    }
    if (stage == 0)
    {
        clcd_print("New Password:", LINE1(0));

        if (key == SW4 || key == SW5)
        {
            return_time =5;
            if(key==SW4)
                new_password[i] = '1';
            else
                new_password[i] = '0';
            clcd_putch('*', LINE2(i));
            i++;
        }

        if (i == 4)
        {
            new_password[4] = '\0';
            i = 0;
            stage = 1;
            clear_screen();
        }
    }
    else if (stage == 1)
    {
        clcd_print("Confirm Pass:", LINE1(0));

        if (key == SW4 || key == SW5)
        {
            return_time = 5;
            if(key==SW4)
                confirm_password[i] = '1';
            else
                confirm_password[i] = '0';
            clcd_putch('*', LINE2(i));
            i++;
        }

        if (i == 4)
        {
            confirm_password[4] = '\0';
            i = 0;
            stage = 2;
            clear_screen();
        }
    }
    else if (stage == 2)
    {
        return_time =5;
        if (strcmp(new_password, confirm_password) == 0)
        {
            ext_eeprom_24C02_str_write(0x00,new_password);
            clcd_print("Password Changed", LINE1(0));
            clcd_print("Successfully", LINE2(2));
            
        }
        else
        {
            clcd_print("Password", LINE1(4));
            clcd_print("Mismatch", LINE2(4));
        }

        result_delay++;
        if (result_delay == 30) // ~3 seconds @ 50ms task
        {
            result_delay = 0;
            stage = 0;
            clear_screen();
            return GOTO_MAINMENU;
        }
    }

    return 0;
}
unsigned char download_screen(unsigned char reset_flag)
{
    static char pos = 0;
    char addr;

    if (reset_flag == RESET_MENU)
    {
        pos = 0;
        if(clear_flag==1)
        {
            puts("# TIME     E   SP");
            puts("\n\r");
        }
            
    }

    else if (log_no == 0 || clear_flag == 0)
    {
        clear_screen();
        clcd_print("No logs ", LINE1(3));
        clcd_print("available", LINE2(2));
        __delay_ms(2000);
        return GOTO_MAINMENU;
    }

    else if (pos < log_no)
    {
        // Clear screen and show progress
        clear_screen();
        clcd_print("Downloading log", LINE1(1));

        addr = 0x05 + (pos * 10);

        for (char i = 0; i < 10; i++)
            log[i] = ext_eeprom_24C02_read(addr + i);

        log[10] = '\0';

        putchar(pos + '0');
        putchar(' ');
        putchar(log[0]);
        putchar(log[1]);
        putchar(':');
        putchar(log[2]);
        putchar(log[3]);
        putchar(':');
        putchar(log[4]);
        putchar(log[5]);
        putchar(' ');
        putchar(log[6]);
        putchar(log[7]);
        putchar(' ');
        putchar(' ');
        putchar(log[8]);
        putchar(log[9]);
        puts("\n\r");
        __delay_us(500);

        pos++;
    }
    else if(pos==log_no)
    {
        clear_screen();
        clcd_print("Download Done", LINE1(3));
        __delay_ms(2000);
        return GOTO_MAINMENU;
    }
}



