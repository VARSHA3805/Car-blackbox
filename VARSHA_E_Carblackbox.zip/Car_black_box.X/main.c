 /* 
 * File:   main.h
 * Author: VARSHA E
 *
 * Created on 22 May, 2025, 7:42 PM
 */

#include "main.h"
#pragma config WDTE =OFF
void init_config()
{
    //initialize i2c
    init_i2c(100000);
    //initialize rtc
    init_ds1307();
    //initialize adc
    init_adc();
    //initialize clcd
    init_clcd();
    //initialize digital keypad
    init_digital_keypad();
    //initialize timer
    init_timer2();
    
    init_uart(9600);
    
    //peripheral interrupt enable bit for timer2
    PEIE = 1;
    //enable all the global interrupt
    GIE = 1;
}

void main()
{
    unsigned char control_flag = DASHBOARD_SCREEN,key,press,view_return;
    unsigned char event[3] = "ON";
    unsigned char speed = 0;
    unsigned char *gear[]={"GN","GR","G1","G2","G3","G4"};
    unsigned char gr=0;
    unsigned char reset_flag,menu_pos,screen;
    init_config();
    
    log_event(event , speed);
    ext_eeprom_24C02_str_write(0x00,"1010");

    while(1)
    {
        speed = read_adc() / 10.3;
        
        if(control_flag == MAINMENU_SCREEN)           
            key = read_digital_keypad(LEVEL);
        else
            key = read_digital_keypad(STATE);      
        if(key == SW1)
        {
            //collision
            strcpy(event,"CO");
            log_event(event , speed);
        }
        else if(key == SW2&&gr<6)
        {
            //increment gear
            strcpy(event,gear[gr]);
            gr++;
            log_event(event , speed);
            
        }
        else if(key == SW3&&gr>0)
        {
            //decrement gear
            gr--; 
            strcpy(event,gear[gr]);
            log_event(event , speed);
        }
        else if ((key == SW4 || key == SW5) && control_flag == DASHBOARD_SCREEN)
        {
            control_flag = LOGIN_SCREEN;
            
            clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
            __delay_us(500);
            clcd_print("ENTER PASSWORD",LINE1(1));
            clcd_write(LINE2(4), INST_MODE);
            clcd_write(DISP_ON_AND_CURSOR_ON, INST_MODE);
            __delay_us(500);
            
            reset_flag = RESET_PASSWORD;
            TMR2ON = 1; 
        }
        else if (control_flag == MAINMENU_SCREEN && press == LONGPRESS_SW4)
        {
            switch (menu_pos)
            {
                case 0:
                    control_flag = VIEW_LOG_SCREEN;
                    clear_screen();
                    press=ALL_RELEASED;
                    reset_flag=RESET_MENU;
                    break;
                case 1:
                    control_flag = CLEAR_LOG_SCREEN;
                    clear_screen();
                    press=ALL_RELEASED;
                    reset_flag=RESET_MENU;
                    break;
                case 2:
                    control_flag = DOWNLOAD_LOG_SCREEN;
                    clear_screen();
                    press=ALL_RELEASED;
                    reset_flag=RESET_MENU;
                    break;
                case 3:
                    control_flag = SET_TIME_SCREEN;
                    clear_screen();
                    press=ALL_RELEASED;
                    reset_flag=RESET_MENU;
                    break;
                case 4:
                    control_flag = CHANGE_PASSWD_SCREEN;
                    clear_screen();
                    press=ALL_RELEASED;
                    reset_flag=RESET_MENU;
                    break;
                
            }
        }
        else if (control_flag == VIEW_LOG_SCREEN && view_return == LONGPRESS_SW5)
        {
            clear_screen();
            control_flag = MAINMENU_SCREEN;
            view_return == ALL_RELEASED;
        }

        switch(control_flag)
        {
            case DASHBOARD_SCREEN:
                display_dashboard(event,speed);
                break;
            case LOGIN_SCREEN:
                switch(login(key,reset_flag))
                {
                    case RETURN_BACK :
                        clear_screen();
                        control_flag = DASHBOARD_SCREEN;
                        clcd_write(DISP_ON_AND_CURSOR_OFF, INST_MODE);
                        __delay_us(500);
                        TMR2ON = 0;
                        break;
                    case LOGIN_SUCCESS :
                        clear_screen();
                        control_flag = MAINMENU_SCREEN; 
                        clcd_write(DISP_ON_AND_CURSOR_OFF, INST_MODE);
                        __delay_us(500);
                        reset_flag = RESET_MENU ;
                        continue;
                }
                break;
            case MAINMENU_SCREEN:
                press=press_type(key);
                menu_pos = menu_screen(press,reset_flag);
                switch(menu_pos)
                {
                case RETURN_BACK:
                    control_flag = DASHBOARD_SCREEN;
                    break;
                }
                break;
            case VIEW_LOG_SCREEN:
                switch(viewlog_screen(reset_flag))
                {
                    case GOTO_DASHBOARD :
                        clear_screen();
                        control_flag = DASHBOARD_SCREEN;
                        TMR2ON = 0;
                        break;
                    case GOTO_MAINMENU :
                        clear_screen();
                        control_flag = MAINMENU_SCREEN;
                        return_time=7;
                        break;                        
                }
                
            break;
            case CLEAR_LOG_SCREEN:
                switch(clear_log(reset_flag))
                {
                    case GOTO_DASHBOARD :
                        clear_screen();
                        control_flag = DASHBOARD_SCREEN;
                        TMR2ON = 0;
                        break;
                    case GOTO_MAINMENU :
                        clear_screen();
                        control_flag = MAINMENU_SCREEN;
                        return_time=7;
                        break;                        
                }
                
            break;
            case CHANGE_PASSWD_SCREEN:
                screen = reset_password(key,reset_flag);
                switch(screen)
                {
                case GOTO_MAINMENU :
                        clear_screen();
                        control_flag = MAINMENU_SCREEN;
                        return_time=7;
                        break;
                }
                break;
            case SET_TIME_SCREEN:
                switch(set_time_screen(reset_flag))
                {
                    case GOTO_DASHBOARD :
                        clear_screen();
                        control_flag = DASHBOARD_SCREEN;
                        TMR2ON = 0;
                        break;
                    case GOTO_MAINMENU :
                        clear_screen();
                        control_flag = MAINMENU_SCREEN;
                        return_time=7;
                        break;                        
                }
                break;
            case DOWNLOAD_LOG_SCREEN :
                switch(download_screen(reset_flag))
                {
                    case GOTO_MAINMENU :
                        clear_screen();
                        control_flag = MAINMENU_SCREEN;
                        return_time=7;
                        break;     
                break;  
                }
        }
        reset_flag = RESET_NOTHING;
    }
}
