 /* 
 * File:   main.h
 * Author: VARSHA E
 *
 * Created on 22 May, 2025, 7:42 PM
 */

#ifndef MAIN_H
#define	MAIN_H

#include "adc.h"
#include "clcd.h"
#include "digital_keypad.h"
#include "car_blackbox_def.h"
#include "ds1307.h"
#include "i2c.h"
#include <xc.h>
#include "string.h"
#include "EEprom.h"
#include "timers.h"
#include "uart.h"
#define DASHBOARD_SCREEN   0x00
#define LOGIN_SCREEN       0x01
#define MAINMENU_SCREEN    0x02

#define RESET_PASSWORD     0x11
#define RESET_NOTHING      0x22
#define RETURN_BACK        0x33
#define LOGIN_SUCCESS      0x44
#define RESET_MENU         0x55
#define LONGPRESS_SW4      0x66
#define SHORTPRESS_SW4     0x77
#define LONGPRESS_SW5      0x88
#define SHORTPRESS_SW5     0x99

#define VIEW_LOG_SCREEN         0x90
#define CLEAR_LOG_SCREEN        0x91
#define DOWNLOAD_LOG_SCREEN     0x92
#define SET_TIME_SCREEN         0x93
#define CHANGE_PASSWD_SCREEN    0x94

#define GOTO_MAINMENU   0x81
#define GOTO_DASHBOARD  0x82

extern unsigned char return_time;


#endif	/* MAIN_H */

